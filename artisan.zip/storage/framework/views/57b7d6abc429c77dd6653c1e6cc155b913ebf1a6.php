<?php $__env->startSection('title','Home page - shopZay'); ?>
<?php $__env->startSection('content'); ?>
<div class="text-center">
  
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\shopZay\resources\views/welcome.blade.php ENDPATH**/ ?>