@extends('layouts.app')
@section('title','Home page - shopZay')
@section('content')
<div class="text-center">
  
</div>
    
@endsection